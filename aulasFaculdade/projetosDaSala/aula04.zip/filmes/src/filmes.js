
export default [
    { nome: 'O Poderoso Chefão', genero: 'Drama/Ação', ano: 1972 },
    { nome: 'As Branquelas', genero: 'Comédia', ano: 2004 },
    { nome: 'Sexta-feira 13', genero: 'Terror', ano: 1980 },
    { nome: 'Matrix', genero: 'Ficção Científica/Ação', ano: 1999 },
    { nome: 'Kung-fu Panda', genero: 'Animação', ano: 2008 },
];