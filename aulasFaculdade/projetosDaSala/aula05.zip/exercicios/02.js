const multiplicar = ( numeros, valor ) => numeros.map( e => e * valor );

console.log( multiplicar( [ 10, 20, 30, 40, 50 ], 2 ) );